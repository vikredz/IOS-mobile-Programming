

//  PresidentDetailViewModel.swift
//  President
//
//  Created by Vikramaditya Reddy 

import Foundation

struct PresidentDetailViewModel 
{
    
    private var president: President

    
    var name: String 
    {
        president.name
    }
    
    var number: Int 
    {
        president.number
    }
    
    var startDate: String 
    {
        president.startDate
    }
    
    var endDate: String 
    {
        president.endDate
    }
    
    var nickname: String 
    {
        president.nickname
    }
    
    var politicalParty: String 
    {
        president.politicalParty
    }
    
    var ordinalNumber: String 
    {
        president.ordinalNumber
    }
    

    init(president: President) 
    {
        self.president = president
    }


    static var `default`: PresidentDetailViewModel 
    {
        let defaultPresident = President(
            name: "George Washington",
            number: 1,
            startDate: "April 30, 1789",
            endDate: "March 3, 1797",
            nickname: "\"Father of His Country\"",
            politicalParty: "None"
        )
        return PresidentDetailViewModel(president: defaultPresident)
    }
}

