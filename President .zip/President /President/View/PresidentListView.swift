

//  PresidentListView.swift
//  President
//
//  Created by Vikramaditya Reddy 


//Main View


import SwiftUI

struct PresidentsListView: View 
{
    
    @StateObject private var presidentListVM = PresidentListViewModel()

    
    var body: some View
    {
        NavigationStack 
        {
            presidentsList
        }
        .onAppear(perform: loadData)
    }

    
    private var presidentsList: some View
    {
        List 
        {
            ForEach(presidentListVM.presidents, id: \.name)
            {
                presidentVM in
                NavigationLink(destination: PresidentDetailView(president: presidentVM)) 
                {
                    PresidentCell(president: presidentVM)
                }
            }
        }
        .listStyle(.plain)
        .navigationTitle("Presidents")
        .navigationBarTitleDisplayMode(.inline)
    }

    
    private func loadData()
    {
        presidentListVM.loadPropertyList()
    }
}


struct PresidentsListView_Previews: PreviewProvider 
{
    static var previews: some View 
    {
        PresidentsListView()
    }
}
