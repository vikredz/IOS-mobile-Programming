

//  PresidentDetailView.swift
//  President
//
//  Created by Vikramaditya Reddy 
//

//Detail view of the selected president

import SwiftUI

struct PresidentDetailView: View 
{
    
    
    var president: PresidentDetailViewModel

    
    var body: some View 
    {
        VStack(spacing: 12)
        {
            presidentName
            presidentDetails
            presidentImage
            nicknameSection
            politicalPartySection
        }  
    }

    
    
    private var presidentName: some View 
    {
        Text(president.name)
            .font(.largeTitle)
            .fontWeight(.heavy)
            .multilineTextAlignment(.center)
    }

    
    private var presidentDetails: some View
    {
        Group 
        {
            Text("\(president.ordinalNumber) President of the United States of America")
                .fontWeight(.semibold)

            Text("(\(president.startDate) to \(president.endDate))")
        }
    }
    
    

    private var presidentImage: some View 
    {
        Image("seal")
            .resizable()
            .scaledToFit()
            .cornerRadius(12)
            .padding(.horizontal)
    }
    
    
    private var nicknameSection: some View
    {
        VStack 
        {
            Text("Nickname")
                .fontWeight(.semibold)
                .font(.callout)

            Text(president.nickname)
                .padding(10)
                .multilineTextAlignment(.center)
        }
    }
    

    private var politicalPartySection: some View 
    {
        Group 
        {
            if president.politicalParty != "None" 
            {
                Text("Political Party")
                    .fontWeight(.semibold)
                Text(president.politicalParty)
            }
        }
    }
}


struct PresidentDetailView_Previews: PreviewProvider 
{
    static var previews: some View 
    {
        PresidentDetailView(president: PresidentDetailViewModel.default)
    }
}
