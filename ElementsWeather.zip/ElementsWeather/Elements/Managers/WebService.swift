//##########################################################
//#                                                        #
//# CSCI 521        Graduate Project           FALL 2023   #
//#                                                        #
//# Developer: Vikramaditya Reddy Varkala                  #
//#                                                        #
//##########################################################

//
//  WebService.swift
//  Elements
//
//  Created by Vikramaditya Reddy on 11/23/23.
//

import Foundation

class WebService 
{
    func fetchWeather(for city: String) async throws -> Weather? 
    {
        guard let url = URL(string: "https://api.openweathermap.org/data/2.5/weather?q=\(city)&APPID=09eb2793416b781483974c438016c3ef&units=imperial") else 
        {
            return nil
        }
        
        let (data, _) = try await URLSession.shared.data(from: url)
        
        let weatherResponse = try? JSONDecoder().decode(WeatherResponse.self, from: data)
        
        return weatherResponse?.main ?? nil
    }
}
