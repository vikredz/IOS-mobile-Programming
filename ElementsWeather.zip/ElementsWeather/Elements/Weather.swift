
//
//  Weather.swift
//  Elements
//
//  Created by Vikramaditya Reddy
//

import Foundation

struct WeatherResponse: Decodable 
{
    var main: Weather
}

struct Weather: Decodable 
{
    var temp: Double?
    var humidity: Double?
}

