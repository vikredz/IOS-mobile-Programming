
//
//  SearchViewModel.swift
//  Elements
//
//  Created by Vikramaditya Reddy
//

import Foundation

@MainActor
class SearchViewModel: ObservableObject 
{
    
    private var webService = WebService()
    
    @Published var weather = Weather()
    @Published var cityName = ""
    
    var temperature: String 
    {
        if let temp = weather.temp 
        {
            return String(format: "%.0f\u{2109}", temp)
        } else 
        {
            return ""
        }
    }
    
    var humidity: String 
    {
        if let humidity = weather.humidity 
        {
            return String(format: "%.0f%%", humidity)
        } else 
        {
            return ""
        }
    }
    
    func search() async 
    {
        if let city = cityName.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed) {
            await fetchWeather(for: city)
        }
    }
    
    private func fetchWeather(for city: String) async 
    {
        weather = await (try? webService.fetchWeather(for: city)) ?? Weather()
    }
}

