

//
//  LoadingView.swift
//  Elements
//
//  Created by Vikramaditya Reddy
//

import SwiftUI

struct LoadingView: View 
{
    var body: some View 
    {
        fullScreenProgressView
    }

    private var fullScreenProgressView: some View 
    {
        ProgressView()
            .progressViewStyle(CircularProgressViewStyle(tint: .white))
            .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

struct LoadingView_Previews: PreviewProvider {
    static var previews: some View {
        LoadingView()
    }
}
