//
//  LocationSearchView.swift
//  Elements
//
//  Created by Vikramaditya Reddy on 11/22/23.
//

import SwiftUI
import MapKit

struct LocationSearchView: View {
    @State private var query = ""
    @State private var searchResults: [MKMapItem] = []
    
    var body: some View {
        NavigationView {
            List {
                TextField("Search", text: $query, onCommit: {
                    search()
                })
                .textFieldStyle(RoundedBorderTextFieldStyle())
                
                ForEach(searchResults, id: \.self) { item in
                    Button(action: {
                        saveLocation(item.placemark)
                    }) {
                        VStack(alignment: .leading) {
                            Text(item.name ?? "")
                            Text(item.placemark.title ?? "")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                        }
                    }
                }
            }
            .navigationBarTitle("Search Location")
        }
    }
    
    func search() {
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = query
        
        let search = MKLocalSearch(request: request)
        search.start { response, _ in
            searchResults = response?.mapItems ?? []
        }
    }

    func saveLocation(_ placemark: CLPlacemark) {
        // Add logic to save location
        print("Location to save: \(placemark)")
    }
}

struct LocationSearchView_Previews: PreviewProvider {
    static var previews: some View {
        LocationSearchView()
    }
}
