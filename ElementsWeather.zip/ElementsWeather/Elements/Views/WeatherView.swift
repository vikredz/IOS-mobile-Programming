
//
//  WeatherView.swift
//  Elements
//
//  Created by Vikramaditya Reddy 
//


import SwiftUI

struct WeatherView: View {
    var weather: ResponseBody
    @State private var appear = false
    @State private var showSearchView = false
    @State private var isButtonPressed = false // For button animation
    @State private var panelVisible = false // For bottom panel animation
    @State private var isGlowing = false // For glowing animation
    @State private var isRotating = false
    @State private var isPulsating = false
    @State private var currentImageIndex = 0 // For cycling images

    let imageNames = ["weathercover1", "weathercover2", "weathercover"]
    
    var body: some View {
        NavigationView {
            ZStack(alignment: .leading) {
                mainContent
                bottomPanel

                
                VStack {
                    HStack {
                        Spacer()
                        Button(action: {
                            isButtonPressed = true
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                                showSearchView = true
                                isButtonPressed = false
                            }
                        }) {
                            Image(systemName: "magnifyingglass")
                                .font(.title)
                                .padding()
                                .background(isButtonPressed ? Color.gray : Color.white)
                                .foregroundColor(Color.black)
                                .clipShape(Circle())
                                .scaleEffect(isButtonPressed ? 1.2 : 1.0)
                        }
                        .animation(.easeInOut, value: isButtonPressed)
                        .padding()
                    }
                    Spacer()
                }

                NavigationLink(destination: SearchView(), isActive: $showSearchView) {
                    EmptyView()
                }
            }
            .edgesIgnoringSafeArea(.bottom)
            .background(Color.black)
            .preferredColorScheme(.dark)
            .onAppear {
                            appear = true
                            panelVisible = true
                            setUpImageCycling()
                        }
        }
    }

    private var mainContent: some View 
    {
        VStack(alignment: .leading)
        {
            weatherHeader
            Spacer()
            weatherDetails
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var weatherHeader: some View 
    {
        VStack(alignment: .leading, spacing: 5)
        {
            Text(weather.name)
                .bold().font(.custom("Baskerville-Bold", size: 35))
                .shadow(color: .gray, radius: 2, x: 0, y: 2)
                .gradientForeground(colors: [Color.red, Color.orange])
            Text("Today, \(Date().formatted(.dateTime.month().day().hour().minute()))")
                .fontWeight(.light)
                .opacity(appear ? 1 : 0)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var weatherDetails: some View {
        VStack 
        {
            weatherMainInfo
            Spacer().frame(height: 80)
            weatherImage
            Spacer()
        }
        .frame(maxWidth: .infinity)
    }

    private var weatherMainInfo: some View 
    {
        HStack 
        {
            VStack(spacing: 20) {
                Image(systemName: "cloud.fill")
                    .font(.system(size: 40))
                Text(weather.weather[0].main)
                    .scaleEffect(appear ? 1.1 : 1.0)
                    .animation(.easeInOut(duration: 1), value: appear)
            }
            .frame(width: 150, alignment: .leading)

            Spacer()

            Text(weather.main.feels_like.roundDouble() + "°")
                .font(.system(size: 75))
                .fontWeight(.bold)
                .gradientForeground(colors: [Color.red, Color.orange])
                .padding()
                .rotation3DEffect(.degrees(appear ? 0 : -90), axis: (x: 0, y: 1, z: 0))
                .animation(.spring(), value: appear)
        }
    }

    private var weatherImage: some View 
    {
           Image(imageNames[currentImageIndex])
               .resizable()
               .aspectRatio(contentMode: .fit)
               .frame(width: 350)
               .offset(y: -110)
       }



    private var bottomPanel: some View 
    {
        VStack
        {
            Spacer()
            VStack(alignment: .leading, spacing: 20) {
                Text("WEATHER NOW")
                    .bold().padding(.bottom)
                    .gradientForeground(colors: [Color.black, Color.black])

                HStack 
                {
                    WeatherRow(logo: "thermometer", name: "Min temp", value: weather.main.temp_min.roundDouble() + "°")
                    Spacer()
                    WeatherRow(logo: "thermometer", name: "Max temp", value: weather.main.temp_max.roundDouble() + "°")
                }

                HStack 
                {
                    WeatherRow(logo: "wind", name: "Wind speed", value: weather.wind.speed.roundDouble() + "m/s")
                    Spacer()
                    WeatherRow(logo: "humidity", name: "Humidity", value: weather.main.humidity.roundDouble() + "%")
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
            .padding(.bottom, 20)
            .foregroundColor(Color.black)
            .background(panelVisible ? Color(hue: 1.0, saturation: 0.521, brightness: 0.88) : Color.clear)
            .cornerRadius(20, corners: [.topLeft, .topRight])
            .offset(y: panelVisible ? 0 : UIScreen.main.bounds.height)
            .animation(.spring(), value: panelVisible)
        }
    }
    private func setUpImageCycling() 
    {
            Timer.scheduledTimer(withTimeInterval: 3, repeats: true) 
        { _ in
                withAnimation(.easeInOut) 
            {
                    currentImageIndex = (currentImageIndex + 1) % imageNames.count
                }
            }
        }

}

struct WeatherView_Previews: PreviewProvider 
{
    static var previews: some View 
    {
        WeatherView(weather: previewWeather)
    }
}

extension View 
{
    func gradientForeground(colors: [Color]) -> some View 
    {
        self.overlay(LinearGradient(gradient: Gradient(colors: colors), startPoint: .topLeading, endPoint: .bottomTrailing))
            .mask(self)
    }
}
