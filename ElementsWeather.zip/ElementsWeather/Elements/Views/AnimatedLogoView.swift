
//  AnimatedLogoView.swift
//  Elements
//
//  Created by Vikramaditya Reddy
//

import SwiftUI

struct AnimatedLogoView: View 
{
    var logo: String
    @State private var isAnimating = false

    var body: some View 
    {
        Image(systemName: logo)
            .scaleEffect(isAnimating ? 1.2 : 1.0)
            .animation(Animation.easeInOut(duration: 0.7).repeatForever(autoreverses: true), value: isAnimating)
            .onAppear
        {
            isAnimating = true
        }
    }
}








