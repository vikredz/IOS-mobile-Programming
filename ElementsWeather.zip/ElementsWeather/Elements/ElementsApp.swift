
//
//  ElementsApp.swift
//  Elements
//
//  Created by Vikramaditya Reddy
//

import SwiftUI

@main
struct ElementsApp: App 
{
    var body: some Scene 
    {
        WindowGroup 
        {
            SplashScreenView()
        }
    }
}
