
//
//  ContentView.swift
//  LoanTemperature
//
//  Created by Vikramaditya Reddy 
//



import SwiftUI

struct ContentView: View 
{
    var body: some View 
    {
        TabView
        {
            
            // Temperature Conversion Tab
            TempView()
                .tabItem
            {
                Label("Temperature", systemImage: "thermometer")
            }
            
            
            // Mortgage Loan Calculator Tab
            LoanView()
                .tabItem 
            {
                Label("Mortgage", systemImage: "house")
            }
            
        }
    }
}

struct ContentView_Previews: PreviewProvider 
{
    static var previews: some View 
    {
        ContentView()
    }
}
