
//
//  LoanTemperatureApp.swift
//  LoanTemperature
//
//  Created by Vikramaditya Reddy
//

import SwiftUI

@main
struct LoanTemperatureApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
