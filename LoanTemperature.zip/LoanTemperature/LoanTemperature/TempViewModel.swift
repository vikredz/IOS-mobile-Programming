
//  TempViewModel.swift
//  LoanTemperature
//
//  Created by Vikramaditya Reddy on 
//

import Foundation

class TempViewModel: ObservableObject 
{
    
    // Published properties
    @Published var temperatures = [Array(-129...134), Array(-90...57)]
    @Published var selectedtemp = 0
    @Published var selectedfarenheit = 75 //defalut values user sees
    @Published var selectedcelcius = 24  //defalut values user sees
    @Published var showAlert = false
    
    // Methods for temperature conversion
    
    // Converts Fahrenheit to Celsius
    func fahrenheitToCelsius() -> Double 
    {
        return (Double(selectedfarenheit) - 32.0) * (5.0/9.0)
    }

    
    // Converts Celsius to  Fahrenheit
    func CelsiusToFarenheit() -> Double 
    {
        return (Double(selectedcelcius) * (9/5)) + 32.0
    }
    
}
