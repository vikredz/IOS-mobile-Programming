
//  TempView.swift
//  LoanTemperature
//
//  Created by Vikramaditya Reddy 
//

import SwiftUI

struct TempView: View 
{
    @StateObject private var viewModel = TempViewModel()
    
    var body: some View 
    {
        VStack 
        {
            headerText
            
            conversionPicker
            
            if viewModel.selectedtemp == 0 
            {
                fahrenheitToCelsiusPicker
            } 
            else
            {
                celsiusToFahrenheitPicker
            }
            
            Spacer()
        }
    }
    
    
    private var headerText: some View 
    {
        Text("Temperature Conversion")
            .font(.title)
            .bold()
    }
    
    
    private var conversionPicker: some View 
    {
        Picker("Setting", selection: $viewModel.selectedtemp) 
        {
            Text("\u{2109} \u{2B62} \u{2103}").tag(0)
            Text("\u{2103} \u{2B62} \u{2109}").tag(1)
        }
        .pickerStyle(SegmentedPickerStyle())
        .padding(.horizontal)
    }
    
    
    private var fahrenheitToCelsiusPicker: some View 
    {
        Group 
        {
            Picker("Fahrenheit to Celsius", selection: $viewModel.selectedfarenheit) 
            {
                ForEach(viewModel.temperatures[viewModel.selectedtemp], id: \.self)
                {
                    Text("\($0) \u{2109}")
                }
            }
            .pickerStyle(WheelPickerStyle())
            
            let c = viewModel.fahrenheitToCelsius()
            Text("\(c, specifier: "%.2f") \u{2103}")
                .font(.title3)
                .bold()
        }
    }
    
    
    private var celsiusToFahrenheitPicker: some View 
    {
        Group 
        {
            Picker("Celsius to Fahrenheit", selection: $viewModel.selectedcelcius) 
            {
                ForEach(viewModel.temperatures[viewModel.selectedtemp], id: \.self) 
                {
                    Text("\($0) \u{2103}")
                }
            }
            .pickerStyle(WheelPickerStyle())
            
            let f = viewModel.CelsiusToFarenheit()
            Text("\(f, specifier: "%.2f") \u{2109}")
                .font(.title3)
                .bold()
        }
    }
}


struct TempView_Previews: PreviewProvider
{
    static var previews: some View 
    {
        TempView()
    }
}
