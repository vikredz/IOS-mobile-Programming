//##########################################################
//#                                                        #
//# CSCI 521           ASSIGNMENT-3            FALL 2023   #
//#                                                        #
//# Developers: Vikramaditya Reddy Varkala                 #
//#                                                        #
//##########################################################

//
//  ContentView.swift
//  LoanTemperature
//
//  Created by Vikramaditya Reddy on 10/22/23.
//



import SwiftUI

struct ContentView: View 
{
    var body: some View 
    {
        TabView
        {
            
            // Temperature Conversion Tab
            TempView()
                .tabItem
            {
                Label("Temperature", systemImage: "thermometer")
            }
            
            
            // Mortgage Loan Calculator Tab
            LoanView()
                .tabItem 
            {
                Label("Mortgage", systemImage: "house")
            }
            
        }
    }
}

struct ContentView_Previews: PreviewProvider 
{
    static var previews: some View 
    {
        ContentView()
    }
}
