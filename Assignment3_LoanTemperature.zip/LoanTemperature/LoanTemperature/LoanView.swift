//##########################################################
//#                                                        #
//# CSCI 521           ASSIGNMENT-3            FALL 2023   #
//#                                                        #
//# Developers: Vikramaditya Reddy Varkala                 #
//#                                                        #
//##########################################################

//
//  LoanView.swift
//  LoanTemperature
//
//  Created by Vikramaditya Reddy on 10/22/23.
//

import SwiftUI

struct LoanView: View 
{
    
    @StateObject private var viewModel = LoanViewModel()
    
    var body: some View 
    {
        VStack 
        {
            header
            
            principalInputField
            
            interestStepper
            
            interestRateDisplay
            
            numberOfYearsDisplay
            
            yearsSlider
            
            calculateButton
            
            monthlyPaymentDisplay
            
            Spacer()
        }
        .alert(isPresented: $viewModel.showalert, content: errorAlert)
    }
    
    
    private var header: some View 
    {
        Text("Loan Calculater")
            .font(.title)
            .bold()
            .padding()
    }
    
    
    private var principalInputField: some View 
    {
        TextField("Enter Principal Amount", text: $viewModel.principalAmount)
            .keyboardType(.numbersAndPunctuation)
            .textFieldStyle(RoundedBorderTextFieldStyle())
            .padding(.horizontal)
    }
    
    
    private var interestStepper: some View 
    {
        Stepper(value: $viewModel.intrest, in: 0.01...20.00, step: 0.01) 
        {
            Text("Interest")
                .font(.title3)
                .bold()
        }
        .padding(.horizontal)
    }
    
    
    private var interestRateDisplay: some View 
    {
        rowDisplay(label: "Annual Rate", value: String(format: "%.2f%%", viewModel.intrest))
    }
    

    private var numberOfYearsDisplay: some View 
    {
        rowDisplay(label: "Number of Years", value: String(format: "%.0f years", viewModel.numofYears))
    }
    

    private var yearsSlider: some View 
    {
        Slider(value: $viewModel.numofYears, in: 10.0...30.0, step: 5, minimumValueLabel: Text("10"), maximumValueLabel: Text("30")) 
        {
            Text("Number Of Years")
        }
        .padding(.horizontal)
    }
    
    
    private var calculateButton: some View 
    {
        Button(action: viewModel.calculateMonthlyPayment) 
        {
            Text("Calculate")
                .bold()
                .padding(8)
                .background(Color.black)
                .foregroundColor(.white)
                .clipShape(Capsule())
        }
        .padding()
    }
    
    
    private var monthlyPaymentDisplay: some View
    {
        rowDisplay(label: "Monthly Payment", value: String(format: "$%.2f", viewModel.monthlyPayment))
    }

    
    private func rowDisplay(label: String, value: String) -> some View 
    {
        HStack 
        {
            Text(label)
                .bold()
                .padding()
            
            Spacer()
            
            Text(value)
                .bold()
                .padding()
        }
    }
    
    
    private func errorAlert() -> Alert 
    {
        Alert(
            title: Text("Error"),
            message: Text(viewModel.errorMessage)
        )
    }
}


struct LoanView_Previews: PreviewProvider
{
    static var previews: some View 
    {
        LoanView()
    }
}
