//##########################################################
//#                                                        #
//# CSCI 521           ASSIGNMENT-3            FALL 2023   #
//#                                                        #
//# Developers: Vikramaditya Reddy Varkala                 #
//#                                                        #
//##########################################################
//
//  LoanViewModel.swift
//  LoanTemperature
//
//  Created by Vikramaditya Reddy on 10/10/23.
//

import Foundation

class LoanViewModel: ObservableObject 
{
    
    // Published properties
    @Published var principalAmount: String = ""
    
    @Published var intrest: Double = 4.50//defalut values user sees
    @Published var numofYears: Double = 15.0//defalut values user sees
    @Published var monthlyPayment: Double = 0//defalut values user sees
    @Published var errorMessage = ""
    @Published var showalert = false
    
    // Calculation method
    func calculateMonthlyPayment() 
    {
        //in case user enters invalid number
        guard let principalAmount = Double(principalAmount) else
        {
            errorMessage = "Enter valid Principal Amount"
            showalert = true
            return
        }
        
        
        //in case user enters negative values
        guard principalAmount >= 0 else
        {
            errorMessage = "Principal Amount Can't be a Negative value"
            showalert = true
            return
        }
        
        let R = intrest / 1200
        let N = numofYears * 12
        
    
        let x = (principalAmount * R * pow(1 + R, N))
        let y = pow(1 + R, N) - 1
        monthlyPayment = x / y
    }
}
