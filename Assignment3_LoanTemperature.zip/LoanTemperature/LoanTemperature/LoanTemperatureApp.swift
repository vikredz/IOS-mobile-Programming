//##########################################################
//#                                                        #
//# CSCI 521           ASSIGNMENT-3            FALL 2023   #
//#                                                        #
//# Developers: Vikramaditya Reddy Varkala                 #
//#                                                        #
//##########################################################
//
//  LoanTemperatureApp.swift
//  LoanTemperature
//
//  Created by Vikramaditya Reddy on 10/22/23.
//

import SwiftUI

@main
struct LoanTemperatureApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
