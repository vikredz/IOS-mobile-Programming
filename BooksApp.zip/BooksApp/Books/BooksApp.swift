//
//  BooksApp.swift
//  Books
//
//  Created by Vikramaditya Reddy

import SwiftUI

@main
struct BooksApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
