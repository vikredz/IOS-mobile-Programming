//
//  ContentView.swift
//  Books
//
//  Created by Vikramaditya Reddy 


import SwiftUI

struct ContentView: View 
{
    // Data & Properties
    let book = bookData
    var formatter: NumberFormatter 
    {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        return formatter
    }

    // Main Body
    var body: some View 
    {
        ScrollView(showsIndicators: false) 
        {
            VStack(spacing:25) {
                bookDetailsSection
                categoriesSection
                Divider()
                priceSection
            }
            .padding()
        }
    }

    // book details subview
    private var bookDetailsSection: some View 
    {
        VStack 
        {
            //200X250 dimensions
            Image(book.image)
                .resizable()
                .frame(width: 200, height: 250)
                .cornerRadius(12)
                .shadow(color: .gray, radius: 5, x: 7, y: 7)
            
            Spacer().frame(height: 25)
            
            Text(book.authors)
                .font(.system(size: 18, weight: .semibold))
                .foregroundColor(.gray)
            
            Text(book.title)
                .font(.system(size: 32, weight: .bold))
                .bold()
            
            Text(book.edition)
                .font(.system(size: 24, weight: .bold))
            
            Spacer().frame(height: 30)
            
            Text(book.description)
                .foregroundColor(.gray)
        }
        .frame(alignment: .top)
    }

    //categories subview
    private var categoriesSection: some View
    {
        HStack(spacing: 20) 
        {
            ForEach(book.categories, id: \.self) 
            { 
                item in
                Text(item)
                    .padding(10)
                    .overlay(RoundedRectangle(cornerRadius: 40)
                        .stroke(Color.black, lineWidth: 1.5))
            }
        }
    }
    
    //price subview
    private var priceSection: some View
    {
        Text("Buy for \(NSNumber(value: book.price), formatter: formatter)")
            .padding(20)
            .background(Color.black)
            .cornerRadius(40)
            .foregroundColor(.white)
            
            
    }
}

struct ContentView_Previews: PreviewProvider 
{
    static var previews: some View 
    {
        ContentView()
    }
}

