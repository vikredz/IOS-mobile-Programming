//
//  BookModel.swift
//  Books
//
//  Created by Vikramaditya Reddy
//

import Foundation

struct Book: Identifiable {
    var id = UUID()
    var image: String
    var authors: String
    var title: String
    var edition: String
    var description: String
    var categories: [String]
    var price: Double
}

