//
//  BooksApp.swift
//  Books
//
//  Created by Vikramaditya Reddy on 9/28/23.
//

import SwiftUI

@main
struct BooksApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
