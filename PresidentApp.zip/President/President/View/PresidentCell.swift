//##########################################################
//#                                                        #
//# CSCI 521           ASSIGNMENT-4            FALL 2023   #
//#                                                        #
//# Developers: Vikramaditya Reddy Varkala                 #
//#                                                        #
//##########################################################

//  PresidentCell.swift
//  President
//
//  Created by Vikramaditya Reddy on 11/2/23.


//List View

import SwiftUI

struct PresidentCell: View
{
    

    var president: PresidentDetailViewModel

  
    var body: some View 
    {
        HStack 
        {
            presidentInformation
        }
    }

    
    private var presidentInformation: some View 
    {
        VStack(alignment: .leading) 
        {
            Text(president.name)
                .font(.headline)
                .fontWeight(.heavy)

            Text(president.politicalParty)
                .font(.subheadline)
        }
    }
}


struct PresidentCell_Previews: PreviewProvider 
{
    static var previews: some View 
    {
        PresidentCell(president: PresidentDetailViewModel.default)
            .previewLayout(.sizeThatFits)
    }
}
