//##########################################################
//#                                                        #
//# CSCI 521           ASSIGNMENT-4            FALL 2023   #
//#                                                        #
//# Developers: Vikramaditya Reddy Varkala                 #
//#                                                        #
//##########################################################

//  PresidentsListViewModel.swift
//  President
//
//  Created by Vikramaditya Reddy on 11/2/23.


//this view model reads data from plist file and sort them.

import Foundation

class PresidentListViewModel: ObservableObject 
{
    

    @Published var presidents: [PresidentDetailViewModel] = []


    func loadPropertyList() 
    {
        guard let path = Bundle.main.path(forResource: "presidents", ofType: "plist"),
              let xml = FileManager.default.contents(atPath: path) else {
            fatalError("Unable to access property list presidents.plist")
        }
        
        
        do 
        {
            let decodedPresidents = try decodePresidents(from: xml)
            updatePresidentsList(with: decodedPresidents)
        } 
        catch
        {
            fatalError("Unable to decode property list presidents.plist: \(error.localizedDescription)")
        }
    }

    
    private func decodePresidents(from xmlData: Data) throws -> [President] 
    {
        return try PropertyListDecoder().decode([President].self, from: xmlData)
    }

    
    private func updatePresidentsList(with presidents: [President]) 
    {
        let sortedPresidents = presidents.sorted { $0.number < $1.number }
        self.presidents = sortedPresidents.map(PresidentDetailViewModel.init)
    }
}

