//##########################################################
//#                                                        #
//# CSCI 521           ASSIGNMENT-6           FALL 2023    #
//#                                                        #
//# Developers: Vikramaditya Reddy Varkala                 #
//#                                                        #
//##########################################################

//
//  DarkknightApp.swift
//  Darkknight
//
//  Created by Vikramaditya Reddy on 11/27/23.
//

import SwiftUI

@main
struct DarkknightApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}

