//##########################################################
//#                                                        #
//# CSCI 521           ASSIGNMENT-6           FALL 2023    #
//#                                                        #
//# Developers: Vikramaditya Reddy Varkala                 #
//#                                                        #
//##########################################################

//
//  Fugitive+ViewModel.swift
//  Darkknight
//
//  Created by Vikramaditya Reddy on 11/27/23.
//

import Foundation
import SwiftUI

extension Fugitive {
    var showAlias: String {
        return alias ?? "Undefined"
    }
    
    var showName: String {
        return name ?? "Undefined"
    }

    var showNotes: String {
        return notes ?? "Undefined"
    }

    var showCover: UIImage {
        if let data = cover, let image = UIImage(data: data) {
            return image
        } else {
            return UIImage(named: "nopicture")!
        }
    }
}
