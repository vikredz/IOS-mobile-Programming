//##########################################################
//#                                                        #
//# CSCI 521           ASSIGNMENT-6           FALL 2023    #
//#                                                        #
//# Developers: Vikramaditya Reddy Varkala                 #
//#                                                        #
//##########################################################

//
//  ContentView.swift
//  Darkknight
//
//  Created by Vikramaditya Reddy on 11/27/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            FugitiveListView()
                .tabItem {
                    VStack {
                        Image("running man")
                            .renderingMode(.template)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 20, height: 20)
                            


                        Text("Fugitives")
                    }
                }
            
            InCustodyListView()
                .tabItem {
                    VStack {
                        Image("handcuffs")
                            .renderingMode(.template) 
                            .resizable()
                            .scaledToFit()
                            .frame(width: 20, height: 20)
                          

                        Text("In Custody")
                    }
                }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}

