//##########################################################
//#                                                        #
//# CSCI 521           ASSIGNMENT-6           FALL 2023    #
//#                                                        #
//# Developers: Vikramaditya Reddy Varkala                 #
//#                                                        #
//##########################################################

//
//  InsertFugitiveView.swift
//  Darkknight
//
//  Created by Vikramaditya Reddy on 11/27/23.
//

import SwiftUI
import PhotosUI

struct InsertFugitiveView: View {
    @Environment(\.managedObjectContext) private var dbContext
    @Environment(\.dismiss) private var dismiss
    
    @State private var inputAlias = ""
    @State private var inputName = ""
    @State private var inputNotes = ""
    
    @State var selectedItem: PhotosPickerItem? = nil
    @State private var selectedImageData: Data? = nil

    var body: some View {
        NavigationStack {
            VStack(spacing: 12) {
                HStack {
                    Text("Alias: ")
                    TextField("Insert Alias", text: $inputAlias)
                        .textFieldStyle(.roundedBorder)
                }
                
                HStack {
                    Text("Name: ")
                    TextField("Insert Name", text: $inputName)
                        .textFieldStyle(.roundedBorder)
                }
                
                Text("Notes: ")
                    .frame(maxWidth: .infinity, alignment: .center)
                
                TextEditor(text: $inputNotes)
                    .frame(height: 100)
                    .scrollContentBackground(.hidden)
                    .background(.black)
                    .padding(10)
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(Color.gray, lineWidth: 1)
                    )
                
                PhotosPicker(selection: $selectedItem, matching: .images, photoLibrary:.shared())
                {
                    HStack {
                        Image(systemName: "photo")
                            .font(.system(size: 20))
                        Text("Photo Library")
                            .font(.headline)
                    }
                    .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: 50)
                    .background(Color.blue)
                    .foregroundColor(Color.white)
                    .cornerRadius(20)
                    .padding(.horizontal)
                }
                .onChange(of: selectedItem) { newItem in
                    Task {
                        do {
                            if let data = try await newItem?.loadTransferable(type: Data.self) {
                                DispatchQueue.main.async {
                                    selectedImageData = data
                                }
                            }
                        } catch {
                            print("Error loading image: \(error.localizedDescription)")
                            
                        }
                    }
                }

                
                if let selectedImageData, let uiImage = UIImage(data: selectedImageData) {
                    Image(uiImage: uiImage)
                        .resizable()
                        .scaledToFit()
                        .cornerRadius(25)
                        .padding()
                } else {
                    Image("nopicture")
                        .resizable()
                        .scaledToFit()
                        .cornerRadius(25)
                        .padding()
                }
                
                Spacer()
            }
            .padding()
            .navigationTitle("Add Fugitive")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        let newAlias = inputAlias.trimmingCharacters(in: .whitespaces)
                        let newNotes = inputNotes.trimmingCharacters(in: .whitespaces)
                        let newName = inputName.trimmingCharacters(in: .whitespaces)
                        
                        if !newAlias.isEmpty && !newName.isEmpty {
                            Task(priority: .high) {
                                await storeFugitive(alias: newAlias, name: newName, notes: newNotes)
                            }
                        }
                    }
                }
            }
        }
    }
    
    private func storeFugitive(alias: String, name: String, notes: String) async {
        await dbContext.perform {
            let newFugitive = Fugitive(context: dbContext)
            newFugitive.alias = alias
            newFugitive.name = name
            newFugitive.notes = notes
            newFugitive.inCustody = false
            if let selectedImageData = selectedImageData {
                newFugitive.cover = selectedImageData
            }
            
            do {
                try dbContext.save()
                dismiss()
            } catch {
                print(error)
            }
        }
    }
}

struct InsertFugitiveView_Previews: PreviewProvider {
    static var previews: some View {
        InsertFugitiveView()
    }
}

