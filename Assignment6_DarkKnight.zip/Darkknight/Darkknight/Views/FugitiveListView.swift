//##########################################################
//#                                                        #
//# CSCI 521           ASSIGNMENT-6           FALL 2023    #
//#                                                        #
//# Developers: Vikramaditya Reddy Varkala                 #
//#                                                        #
//##########################################################

//
//  FugitiveListView.swift
//  Darkknight
//
//  Created by Vikramaditya Reddy on 11/27/23.
//

import SwiftUI
import CoreData

struct FugitiveListView: View {
    @Environment(\.managedObjectContext) private var dbContext

    @FetchRequest(
        entity: Fugitive.entity(),
        sortDescriptors: [],
        predicate: NSPredicate(format: "inCustody == false"),
        animation: .default
    ) private var listOfFugitives: FetchedResults<Fugitive>

    @State private var showingInsertFugitiveView = false

    var body: some View {
        NavigationStack {
            List {
                ForEach(listOfFugitives) { fugitive in
                    NavigationLink(destination: DetailView(fugitive: fugitive)) {
                        FugitiveRow(fugitive: fugitive)
                    }
                }
            }
            .listStyle(.plain)
            .navigationTitle("Fugitives")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        showingInsertFugitiveView = true
                    }) {
                        Image(systemName: "plus")
                    }
                }
            }
        }
        .sheet(isPresented: $showingInsertFugitiveView) {
            InsertFugitiveView() 
                .environment(\.managedObjectContext, dbContext)
        }
    }
}

struct FugitiveView_Previews: PreviewProvider {
    static var previews: some View {
        FugitiveListView()
            .environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}




