//##########################################################
//#                                                        #
//# CSCI 521           ASSIGNMENT-6           FALL 2023    #
//#                                                        #
//# Developers: Vikramaditya Reddy Varkala                 #
//#                                                        #
//##########################################################

//
//  FugitiveDetailView.swift
//  Darkknight
//
//  Created by Vikramaditya Reddy on 11/27/23.
//

import SwiftUI

struct DetailView: View {
    @ObservedObject var fugitive: Fugitive
    @Environment(\.managedObjectContext) private var dbContext

    let customAccentColor = Color(red: 243/255, green: 177/255, blue: 11/255)

    var body: some View {
        ScrollView {
            VStack {
                // Alias
                Text(fugitive.showAlias)
                    .font(.largeTitle)
                    .bold()
                    .foregroundColor(customAccentColor)
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .center)

                // Real Name
                HStack {
                    Text("Real Name: ")
                        .font(.title2)
                        .bold()
                        .foregroundColor(customAccentColor)
                    Text(fugitive.showName)
                        .font(.title2)
                }
                .padding([.leading, .trailing, .top])
                .frame(maxWidth: .infinity, alignment: .center)

                ForEach(0..<5, id: \.self) { _ in
                                    Spacer()
                                }

                // Notes
                Text("Notes:")
                    .font(.headline)
                    .bold()
                    .foregroundColor(customAccentColor)
                    .frame(maxWidth: .infinity, alignment: .center)

                Text(fugitive.showNotes)
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .center)

                // Image
                Image(uiImage: fugitive.showCover)
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: .infinity)
                    .cornerRadius(25)
                    .padding()

                // Toggle for In Custody
                Toggle(isOn: Binding(
                    get: { fugitive.inCustody },
                    set: { newValue in
                        updateInCustodyStatus(newValue)
                    }
                )) {
                    Text("In Custody?")
                        .foregroundColor(customAccentColor)
                        .font(.title)
                        .bold()
                }
                .padding()
            }
            .padding(.horizontal)
        }
    }

    private func updateInCustodyStatus(_ isInCustody: Bool) {
        dbContext.performAndWait {
            fugitive.inCustody = isInCustody
            try? dbContext.save()
        }
    }
}

struct DetailView_Previews: PreviewProvider {
    static var previews: some View {
        let context = PersistenceController.preview.container.viewContext
        let fugitive = Fugitive(context: context)
        fugitive.alias = "The Riddler"
        fugitive.name = "Edward Nigma"
        fugitive.notes = "Genius-level intellect, master strategist."
        fugitive.inCustody = true
        
        return DetailView(fugitive: fugitive)
            .environment(\.managedObjectContext, context)
    }
}





