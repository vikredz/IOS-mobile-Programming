//##########################################################
//#                                                        #
//# CSCI 521           ASSIGNMENT-6           FALL 2023    #
//#                                                        #
//# Developers: Vikramaditya Reddy Varkala                 #
//#                                                        #
//##########################################################

//
//  InCustodyListView.swift
//  Darkknight
//
//  Created by Vikramaditya Reddy on 11/27/23.
//

import SwiftUI
import CoreData

struct InCustodyListView: View {
    @Environment(\.managedObjectContext) private var dbContext
    @FetchRequest(
        entity: Fugitive.entity(),
        sortDescriptors: [],
        predicate: NSPredicate(format: "inCustody == true"),
        animation: .default
    ) private var listOfFugitives: FetchedResults<Fugitive>


    var body: some View {
        NavigationStack {
            List {
                ForEach(listOfFugitives) { fugitive in
                    NavigationLink(destination: DetailView(fugitive: fugitive)) {
                        FugitiveRow(fugitive: fugitive)
                    }
                }
                .onDelete(perform: deleteFugitive)
            }
            .listStyle(.plain)
            .navigationTitle("In Custody")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    EditButton()
                }
            }
        }
    }

    private func deleteFugitive(at offsets: IndexSet) {
        withAnimation {
            offsets.forEach { index in
                let fugitive = listOfFugitives[index]
                dbContext.delete(fugitive)
            }

            do {
                try dbContext.save()
            } catch {
                
                print("Error deleting fugitive: \(error.localizedDescription)")
            }
        }
    }

}

struct InCustodyListView_Previews: PreviewProvider {
    static var previews: some View {
        InCustodyListView()
            .environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}








