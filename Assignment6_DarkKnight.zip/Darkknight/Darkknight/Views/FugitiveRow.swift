//##########################################################
//#                                                        #
//# CSCI 521           ASSIGNMENT-6           FALL 2023    #
//#                                                        #
//# Developers: Vikramaditya Reddy Varkala                 #
//#                                                        #
//##########################################################

//
//  FugitiveRow.swift
//  Darkknight
//
//  Created by Vikramaditya Reddy on 11/27/23.


import SwiftUI

struct FugitiveRow: View {
    
    let fugitive: Fugitive
    
    var body: some View {
        HStack(alignment: .top) {
            Image(uiImage: fugitive.showCover)
                .resizable()
                .scaledToFit()
                .cornerRadius(10)
                .frame(width: 80, height: 100)
                .cornerRadius(10)
            
            VStack(alignment: .leading) {
                Text(fugitive.showAlias)
                    .font(.title3)
                    .bold()
//                Text(fugitive.showName)
//                    .foregroundColor((fugitive.name != nil) ? .black : .gray)
//                Text(fugitive.showNotes)
//                    .font(.caption)
            }
        }
    }
}

struct FugitiveRow_Previews: PreviewProvider {
    
    static let viewContext = PersistenceController.preview.container.viewContext
    
    static var fugitive: Fugitive {
        let fugitive = Fugitive(context: viewContext)
        fugitive.alias = "Fugitive 1"
//        fugitive.name = "Some wierd dude"
//        fugitive.notes = "Scar Face"
        fugitive.cover = nil
        
        return fugitive
    }
    
    static var previews: some View {
        FugitiveRow(fugitive: fugitive)
    }
}


