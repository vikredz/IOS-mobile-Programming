//##########################################################
//#                                                        #
//# CSCI 521           ASSIGNMENT-6           FALL 2023    #
//#                                                        #
//# Developers: Vikramaditya Reddy Varkala                 #
//#                                                        #
//##########################################################

//
//  Persistence.swift
//  Darkknight
//
//  Created by Vikramaditya Reddy on 11/27/23.
//

import Foundation
import CoreData

struct PersistenceController {
    static let shared = PersistenceController()

    static var preview: PersistenceController = {
        let result = PersistenceController(inMemory: true)
        let viewContext = result.container.viewContext
        
        let fugitive1 = Fugitive(context: viewContext)
        fugitive1.alias = "Fugitive 1"
        fugitive1.name = "Some wierd guy"
        fugitive1.notes = "Two Face guy"
        fugitive1.cover = nil
        

        let fugitive2 = Fugitive(context: viewContext)
        fugitive2 .alias = "Fugitive 2"
        fugitive2 .name = "Some wierder guy"
        fugitive2 .notes = "scare crow"
        fugitive2 .cover = nil

        do {
            try viewContext.save()
        } catch {
            
            let nsError = error as NSError
            fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
        }
        return result
    }()

    let container: NSPersistentContainer

    init(inMemory: Bool = false) {
        container = NSPersistentContainer(name: "Darkknight")
        if inMemory {
            container.persistentStoreDescriptions.first!.url = URL(fileURLWithPath: "/dev/null")
        }
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
             
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        container.viewContext.automaticallyMergesChangesFromParent = true
    }
}
