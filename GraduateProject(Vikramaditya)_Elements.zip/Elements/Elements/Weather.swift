//##########################################################
//#                                                        #
//# CSCI 521        Graduate Project           FALL 2023   #
//#                                                        #
//# Developer: Vikramaditya Reddy Varkala                  #
//#                                                        #
//##########################################################

//
//  Weather.swift
//  Elements
//
//  Created by Vikramaditya Reddy on 11/23/23.
//

import Foundation

struct WeatherResponse: Decodable 
{
    var main: Weather
}

struct Weather: Decodable 
{
    var temp: Double?
    var humidity: Double?
}

