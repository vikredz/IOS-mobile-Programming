//##########################################################
//#                                                        #
//# CSCI 521        Graduate Project           FALL 2023   #
//#                                                        #
//# Developer: Vikramaditya Reddy Varkala                  #
//#                                                        #
//##########################################################

//
//  ElementsApp.swift
//  Elements
//
//  Created by Vikramaditya Reddy on 10/31/23.
//

import SwiftUI

@main
struct ElementsApp: App 
{
    var body: some Scene 
    {
        WindowGroup 
        {
            SplashScreenView()
        }
    }
}
