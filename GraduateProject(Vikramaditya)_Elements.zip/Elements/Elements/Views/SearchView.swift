//##########################################################
//#                                                        #
//# CSCI 521        Graduate Project           FALL 2023   #
//#                                                        #
//# Developer: Vikramaditya Reddy Varkala                  #
//#                                                        #
//##########################################################

//
//  SearchView.swift
//  Elements
//
//  Created by Vikramaditya Reddy on 11/23/23.
//


import SwiftUI

struct SearchView: View 
{
    
    @StateObject var weatherVM = SearchViewModel()
    @State private var isButtonPressed = false

    var body: some View 
    {
        VStack 
        {
            Spacer()
            Text("Today's Weather")
                .font(.custom("Baskerville-Bold", size: 40))
                .bold()
                .foregroundColor(Color(hue: 1.0, saturation: 0.521, brightness: 0.88)) 
                .padding()
            
            TextField("Enter city name", text: $weatherVM.cityName)
                .textFieldStyle(.roundedBorder)
                .font(.custom("Baskerville-Bold", size: 20))
                .padding(.horizontal, 30)
                .padding(.vertical, 10)
                .foregroundColor(Color(hue: 1.0, saturation: 0.521, brightness: 0.88))
            
            Button(action: 
                    {
                isButtonPressed = true
                Task(priority: .userInitiated) {
                    await weatherVM.search()
                    isButtonPressed = false
                }
            }) {
                Text("Get Weather")
                    .foregroundColor(.white)
                    .font(.custom("Baskerville-Bold", size: 20))
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color(hue: 1.0, saturation: 0.521, brightness: 0.88))
                    .cornerRadius(10)
                    .padding(.horizontal, 30)
                    .scaleEffect(isButtonPressed ? 0.95 : 1.0) // Scale effect
                    .animation(.easeInOut(duration: 0.2), value: isButtonPressed) // Animation
            }
            
            Text(weatherVM.temperature)
                .font(.custom("Baskerville-Bold", size: 50))
                .foregroundColor(Color.white)
                .padding()
            
            Text(weatherVM.humidity)
                .font(.custom("Baskerville-Bold", size: 50))
                .foregroundColor(Color.white)
                .multilineTextAlignment(.center)
                .lineLimit(2)
                .padding()

            Spacer()
        }
        .padding()
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.black)
        .edgesIgnoringSafeArea(.all)
    }
}

struct SearchView_Previews: PreviewProvider 
{
    static var previews: some View 
    {
        SearchView()
    }
}
