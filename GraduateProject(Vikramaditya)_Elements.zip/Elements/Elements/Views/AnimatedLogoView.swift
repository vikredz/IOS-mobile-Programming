//##########################################################
//#                                                        #
//# CSCI 521        Graduate Project           FALL 2023   #
//#                                                        #
//# Developer: Vikramaditya Reddy Varkala                  #
//#                                                        #
//##########################################################
//
//  AnimatedLogoView.swift
//  Elements
//
//  Created by Vikramaditya Reddy on 11/24/23.
//

import SwiftUI

struct AnimatedLogoView: View 
{
    var logo: String
    @State private var isAnimating = false

    var body: some View 
    {
        Image(systemName: logo)
            .scaleEffect(isAnimating ? 1.2 : 1.0)
            .animation(Animation.easeInOut(duration: 0.7).repeatForever(autoreverses: true), value: isAnimating)
            .onAppear
        {
            isAnimating = true
        }
    }
}








