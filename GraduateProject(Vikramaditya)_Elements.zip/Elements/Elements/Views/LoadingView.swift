//##########################################################
//#                                                        #
//# CSCI 521        Graduate Project           FALL 2023   #
//#                                                        #
//# Developer: Vikramaditya Reddy Varkala                  #
//#                                                        #
//##########################################################

//
//  LoadingView.swift
//  Elements
//
//  Created by Vikramaditya Reddy on 10/31/23.
//

import SwiftUI

struct LoadingView: View 
{
    var body: some View 
    {
        fullScreenProgressView
    }

    private var fullScreenProgressView: some View 
    {
        ProgressView()
            .progressViewStyle(CircularProgressViewStyle(tint: .white))
            .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

struct LoadingView_Previews: PreviewProvider {
    static var previews: some View {
        LoadingView()
    }
}
