//##########################################################
//#                                                        #
//# CSCI 521        Graduate Project           FALL 2023   #
//#                                                        #
//# Developer: Vikramaditya Reddy Varkala                  #
//#                                                        #
//##########################################################

//
//  SplashScreenView.swift
//  Elements
//
//  Created by Vikramaditya Reddy on 10/31/23.
//

import SwiftUI

struct SplashScreenView: View 
{
    @State private var isActive = false
    @State private var size = 0.8
    @State private var opacity = 0.5

    var body: some View 
    {
        Group 
        {
            if isActive 
            {
                ContentView()
            } else 
            {
                splashScreen
            }
        }
        .onAppear 
         {
            animateSplashScreen()
        }
    }

    private var splashScreen: some View {
        ZStack {
            Color.black.edgesIgnoringSafeArea(.all)
            VStack {
                logoImage
                appName
                appDescription
            }
            .scaleEffect(size)
            .opacity(opacity)
        }
    }

    private var logoImage: some View {
        Image(systemName: "cloud.sun.rain.fill")
            .font(.system(size: 120))
            .foregroundColor(Color(hue: 1.0, saturation: 0.521, brightness: 0.88))
    }

    private var appName: some View {
        Text("ELEMENTS")
            .font(Font.custom("Baskerville-Bold", size: 40))
            .foregroundColor(.blue.opacity(0.80))
    }

    private var appDescription: some View {
        Text("A Weather App")
            .font(Font.custom("Baskerville-Bold", size: 20))
            .foregroundColor(.gray.opacity(0.80))
    }

    private func animateSplashScreen() {
        withAnimation(.easeIn(duration: 2.0)) {
            size = 0.9
            opacity = 1.0
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            withAnimation {
                isActive = true
            }
        }
    }
}

struct SplashScreenView_Previews: PreviewProvider {
    static var previews: some View {
        SplashScreenView()
    }
}
