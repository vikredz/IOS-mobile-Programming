
//  Constants.swift
//  President
//
//  Created by Vikramaditya Reddy
//

import Foundation

struct Constants {
    
    struct Urls {
        static let presidentsUrl: URL? = URL(string: "https://faculty.cs.niu.edu/~mcmahon/CS321/presidents.json")
    }
}
