

//  PresidentListView.swift
//  President
//
//  Created by Vikramaditya Reddy 


//Main View


import SwiftUI

struct PresidentListView: View {
    
    @StateObject private var viewModel = PresidentListViewModel()
    
    var body: some View
    {
        NavigationStack
        {
            List
            {
                ForEach(viewModel.presidents, id: \.name)
                {
                    presidentVM in
                    NavigationLink(destination: PresidentDetailView(president: presidentVM))
                    {
                        PresidentCell(president: presidentVM)
                    }
                }
                
            }
            .listStyle(.plain)
            .navigationTitle("Presidents")
            .navigationBarTitleDisplayMode(.inline)
        }
        .task {
            await viewModel.getPresidents()
        }
    }
}

struct PresidentListView_Previews: PreviewProvider
{
    static var previews: some View 
    {
        PresidentListView()
    }
}
