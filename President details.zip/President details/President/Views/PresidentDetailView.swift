

//  PresidentDetailView.swift
//  President
//
//  Created by Vikramaditya Reddy
//

//Detail view of the selected president

import SwiftUI

struct PresidentDetailView: View {
    
    var president: PresidentDetailViewModel
    
    var body: some View {
        VStack(spacing:12) {
            Text(president.name)
                .font(.largeTitle)
                .fontWeight(.heavy)
                .multilineTextAlignment(.center)
                .foregroundColor(.black)
                
            
            Text("\(president.ordinalNumber) President of the United States of America")
                           .fontWeight(.semibold)

            Text("(\(president.startDate) to \(president.endDate))")
                       
            Spacer()
            
            AsyncImage(url: URL(string: president.url)) { image in
                image.resizable()
                    .scaledToFit()
                    .cornerRadius(20)
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.gray, lineWidth: 4))
            } placeholder: {
                ProgressView()
            }
            .padding(.horizontal)
            
            Spacer()
                        
            Text("Nickname")
                .fontWeight(.semibold)
                .font(.callout)
                                        
            Text("\(president.nickname)")
                .padding(5)
                .multilineTextAlignment(.center)
            
        
            Text("Political Party")
                .fontWeight(.semibold)
            
            Text(president.politicalParty)
            
        }
    }
}


struct PresidentDetailView_Previews: PreviewProvider 
{
    static var previews: some View 
    {
        PresidentDetailView(president: PresidentDetailViewModel.default)
    }
}
