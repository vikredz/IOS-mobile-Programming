

//  PresidentCell.swift
//  President
//
//  Created by Vikramaditya Reddy 


//List View

import SwiftUI

struct PresidentCell: View {
    
    var president: PresidentDetailViewModel
    
    var body: some View {
        HStack {
            
            AsyncImage(url: URL(string: president.url)) {image in
                image.resizable()
                    .cornerRadius(6)
            } placeholder: {
                ProgressView()
            }
            .frame(width: 45, height: 50)
            
            VStack(alignment: .leading) {
                Text(president.name)
                    .font(.headline)
                    .fontWeight(.heavy)
                Text(president.politicalParty)
                    .font(.subheadline)
            }
            
        }
    }
}


struct PresidentCell_Previews: PreviewProvider 
{
    static var previews: some View 
    {
        PresidentCell(president: PresidentDetailViewModel.default)
    }
}
