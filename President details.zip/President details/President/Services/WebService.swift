

//
//  WebService.swift
//  President
//
//  Created by Vikramaditya Reddy 
//

import Foundation


class WebService {
    func fetchPresidents(url: URL?) async throws -> [USAPresidents] {
        guard let url = url else {
            return []
        }
        
        let (data, _) = try await URLSession.shared.data(from: url)
        
        let presidents = try? JSONDecoder().decode([USAPresidents].self, from: data)
        
        return presidents ?? []
    }
}
