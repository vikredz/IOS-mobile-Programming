

//  PresidentListViewModel.swift
//  President
//
//  Created by Vikramaditya Reddy



import Foundation

@MainActor
class PresidentListViewModel: ObservableObject 
{
    
    @Published var presidents: [PresidentDetailViewModel] = []
    
    func getPresidents() async 
    {
        
        do 
        {
            var presidents = try await WebService().fetchPresidents(url:Constants.Urls.presidentsUrl)
            presidents.sort
            {
                $0.number < $1.number
            }
            
            self.presidents = presidents.map(PresidentDetailViewModel.init)
        } 
        catch
        {
            print(error)
        }
    }
}

