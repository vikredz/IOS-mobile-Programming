

//
//  PresidentApp.swift
//  President
//
//  Created by Vikramaditya Reddy
//

import SwiftUI

@main
struct PresidentApp: App
{
    var body: some Scene 
    {
        WindowGroup 
        {
            PresidentListView()
        }
    }
}
