//##########################################################
//#                                                        #
//# CSCI 521           ASSIGNMENT-5            FALL 2023   #
//#                                                        #
//# Developers: Vikramaditya Reddy Varkala                 #
//#                                                        #
//##########################################################

//
//  Constants.swift
//  President
//
//  Created by Vikramaditya Reddy on 11/18/23.
//

import Foundation

struct Constants {
    
    struct Urls {
        static let presidentsUrl: URL? = URL(string: "https://faculty.cs.niu.edu/~mcmahon/CS321/presidents.json")
    }
}
