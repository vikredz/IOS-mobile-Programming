//##########################################################
//#                                                        #
//# CSCI 521           ASSIGNMENT-5           FALL 2023   #
//#                                                        #
//# Developers: Vikramaditya Reddy Varkala                 #
//#                                                        #
//##########################################################

//  PresidentDetailViewModel.swift
//  President
//
//  Created by Vikramaditya Reddy on 11/2/23.



import Foundation

struct PresidentDetailViewModel 
{
    var president : USAPresidents
    
    
    var name: String {
        return president.name
    }
    
    var number: Int {
        return president.number
    }
    
    var startDate: String {
        return president.startDate
    }
    
    var endDate: String {
        return president.endDate
    }
    
    var nickname: String {
        return president.nickname
    }
    
    var politicalParty : String {
        return president.politicalParty
    }
    
    var url : String {
        return president.url
    }
    
    var ordinalNumber : String {
            return president.ordinalNumber
        }
    
    
    static var `default`: PresidentDetailViewModel
    {
        let president = USAPresidents(
            name: "George Washington",
            number: 1,
            startDate: "April 30, 1789",
            endDate: "March 3, 1797",
            nickname: "\"Father of His Country\"",
            politicalParty: "None",
            url:"https://www.potus.com/wp-content/uploads/2018/08/01_george_washington_1_gallery.jpg")
        return PresidentDetailViewModel(president: president)
    }
}
