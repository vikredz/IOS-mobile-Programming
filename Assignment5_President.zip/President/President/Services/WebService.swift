//##########################################################
//#                                                        #
//# CSCI 521           ASSIGNMENT-5            FALL 2023   #
//#                                                        #
//# Developers: Vikramaditya Reddy Varkala                 #
//#                                                        #
//##########################################################

//
//  WebService.swift
//  President
//
//  Created by Vikramaditya Reddy on 11/18/23.
//

import Foundation


class WebService {
    func fetchPresidents(url: URL?) async throws -> [USAPresidents] {
        guard let url = url else {
            return []
        }
        
        let (data, _) = try await URLSession.shared.data(from: url)
        
        let presidents = try? JSONDecoder().decode([USAPresidents].self, from: data)
        
        return presidents ?? []
    }
}
