//##########################################################
//#                                                        #
//# CSCI 521           ASSIGNMENT-5            FALL 2023   #
//#                                                        #
//# Developers: Vikramaditya Reddy Varkala                 #
//#                                                        #
//##########################################################

//
//  PresidentApp.swift
//  President
//
//  Created by Vikramaditya Reddy on 11/2/23.
//

import SwiftUI

@main
struct PresidentApp: App
{
    var body: some Scene 
    {
        WindowGroup 
        {
            PresidentListView()
        }
    }
}
