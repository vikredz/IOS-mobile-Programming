//##########################################################
//#                                                        #
//# CSCI 521           ASSIGNMENT-2            FALL 2023   #
//#                                                        #
//# Developer: Vikramaditya Reddy Varkala                  #
//#                                                        #
//##########################################################

//
//  DogHumanAgeApp.swift
//  DogHumanAge
//
//  Created by Vikramaditya Reddy on 10/4/23.
//

import SwiftUI

@main
struct DogHumanAgeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
