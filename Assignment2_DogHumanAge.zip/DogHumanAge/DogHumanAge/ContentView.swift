//##########################################################
//#                                                        #
//# CSCI 521           ASSIGNMENT-2            FALL 2023   #
//#                                                        #
//# Developer: Vikramaditya Reddy Varkala                  #
//#                                                        #
//##########################################################

//
//  ContentView.swift
//  DogHumanAge
//
//  Created by Vikramaditya Reddy on 10/4/23.
//



import SwiftUI

struct ContentView: View {
    @StateObject private var viewModel = DogHumanAgeViewModel()
    
// for choosing font name.(not needed for the output)
    //    init() {
    //        for fontFamily in UIFont.familyNames {
    //            for fontName in UIFont.fontNames(forFamilyName: fontFamily) {
    //                print("\(fontName)")
    //            }
    //        }
    //    }
    //
    
    var body: some View 
    {
        ZStack 
        {
            backgroundGradient
            mainContentVStack
        }
        .ignoresSafeArea()
        .alert(isPresented: $viewModel.showalert)
        {
            Alert(
                title: Text("Error"),
                message: Text(viewModel.errorMessage)
            )
        }
    }
    
    
    
    private var backgroundGradient: some View 
    {
        LinearGradient(
            gradient: Gradient(colors: [
                Color(red: 243/255, green: 144/255, blue: 79/255),
                Color(red: 59/255, green: 67/255, blue: 113/255)
            ]),
            startPoint: .top,
            endPoint: .bottom
        )
    }
    
    
    
    private var mainContentVStack: some View 
    {
        VStack 
        {
            titleText
            Spacer().frame(height: 60)
            ageInputField
            Spacer().frame(height: 90)
            dogImage
            Spacer().frame(height: 120)
            calculateButton
            Spacer()
            humanAgeText
        }
        .frame(height: UIScreen.main.bounds.height)
    }
    
    

    private var titleText: some View 
    {
        Text("How old is your Dog?")
            .font(.custom("ArianaVioleta", size: 50))
            .foregroundColor(.white)
            .padding(.top, 80)
            .shadow(color: .blue, radius: 10, x: 0, y: 0)
    }
    
    
    
    private var ageInputField: some View 
    {
        TextField("Enter your dog's age", text: $viewModel.age)
            .keyboardType(.numbersAndPunctuation)
            .font(.custom("ArianaVioleta", size: 25))
            .textFieldStyle(.roundedBorder)
            .padding(.horizontal)
    }
    
    
    private var dogImage: some View 
    {
        Image("dog")
            .resizable()
            .frame(width: 200, height: 200)
            .clipShape(Circle())
            .overlay(Circle().stroke(Color.orange, lineWidth: 1.2))
            .shadow(color: .blue, radius: 10, x: 0, y: 0)
    }
    
    
    
    private var calculateButton: some View 
    {
        Button(action: {
            viewModel.showresult = true
            viewModel.humanAge()
        }) {
            Text("Human Age")
                .foregroundColor(.blue)
                .font(.custom("ArianaVioleta", size: 26))
                
        }
        .padding(14)
        .background(Color.white)
        .cornerRadius(25)
    }
    
    
    private var humanAgeText: some View 
    {
        VStack 
        {
            Spacer()
            if viewModel.showresult && !viewModel.showalert 
            {
                Text("In human years, Your dog is \(viewModel.resultText)!")
                    .foregroundColor(.white)
                    .font(.custom("ArianaVioleta", size: 35))
                    .shadow(color: .orange, radius: 10, x: 0, y: 0)
            }
            Spacer().frame(height: 40)
        }
    }
}


struct ContentView_Previews: PreviewProvider 
{
    static var previews: some View 
    {
        ContentView()
    }
}
