//##########################################################
//#                                                        #
//# CSCI 521           ASSIGNMENT-2            FALL 2023   #
//#                                                        #
//# Developer: Vikramaditya Reddy Varkala                  #
//#                                                        #
//##########################################################

//
//  DogHumanAgeViewModel.swift
//  DogHumanAge
//
//  Created by Vikramaditya Reddy on 10/4/23.
//

import Foundation

class DogHumanAgeViewModel: ObservableObject {
    
    @Published var resultText = "0.00"
    @Published var errorMessage = ""
    @Published var showalert = false
    @Published var age = "" 
    {
        didSet 
        {
            self.showresult = false
        }
    }
    @Published var showresult = false
    
    //EXTRA CREDIT FOR A SEPERATE VIEWMODEL TO CALCULATE AGE
    
    func humanAge() 
    {
        guard let ageValue = Double(self.age) else 
        {
            self.errorMessage = "Please enter a valid age for your dog"
            self.showalert = true
            self.showresult = false
            return
        }
        
        //A dog’s age in human years is equal to 16 times the natural log of the dog’s age, plus 31.
        
        let result = Int((log(ageValue) * 16) + 31)
        self.resultText = String(result)
    }
}
